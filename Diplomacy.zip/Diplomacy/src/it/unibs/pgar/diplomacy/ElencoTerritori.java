package it.unibs.pgar.diplomacy;

import java.util.ArrayList;

public class ElencoTerritori {
	private ArrayList<Territorio> elencoTerritori;
	
	public ElencoTerritori() {
		this.elencoTerritori = null;
	}
	
	public ElencoTerritori(ArrayList<Territorio> elencoTerritori) {
		this.elencoTerritori = elencoTerritori;
	}

	public ArrayList<Territorio> getElencoTerritori() {
		return elencoTerritori;
	}

	public void setElencoTerritori(ArrayList<Territorio> elencoTerritori) {
		this.elencoTerritori = elencoTerritori;
	}
	
	public void aggiungiTerritorio(Territorio territorio) {
		this.elencoTerritori.add(territorio);
	}

}
