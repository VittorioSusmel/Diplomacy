package it.unibs.pgar.diplomacy;
import java.util.ArrayList;

public class DiplomacyMain {
	

	public static void main(String[] args) {
		
		Territorio t1 = new Territorio("Adf", Tipo.TERRA, TipoControllo.CONTROLLATO, true, true, true);
		Territorio t2 = new Territorio("bff", Tipo.TERRA, TipoControllo.VUOTO, false, false, false);
		Territorio t3 = new Territorio("aaa", Tipo.COSTA, TipoControllo.NEUTRO, true, false, false);
		Territorio t4 = new Territorio("fff", Tipo.MARE, TipoControllo.CONTROLLATO, true, true, true);
		Territorio t5 = new Territorio("ggg", Tipo.MARE, TipoControllo.CONTROLLATO, false, false, false);
        
		ArrayList<Territorio> adiacenti1 = new ArrayList<>();
        adiacenti1.add(t2);
        adiacenti1.add(t3);
        
        ArrayList<Territorio> adiacenti2 = new ArrayList<>();
        adiacenti2.add(t1);
        adiacenti2.add(t3);
        
        ArrayList<Territorio> adiacenti3 = new ArrayList<>();
        adiacenti3.add(t2);
        adiacenti3.add(t1);
        adiacenti3.add(t4);
        adiacenti3.add(t5);
        
        
        ArrayList<Territorio> adiacenti4 = new ArrayList<>();
        adiacenti4.add(t5);
        adiacenti4.add(t3);
        
        ArrayList<Territorio> adiacenti5 = new ArrayList<>();
        adiacenti5.add(t4);
        adiacenti5.add(t3);
        
        t1.setTerritoriAdiacenti(adiacenti1);
        t2.setTerritoriAdiacenti(adiacenti2);
        t3.setTerritoriAdiacenti(adiacenti3);
        t4.setTerritoriAdiacenti(adiacenti5);
        t4.setTerritoriAdiacenti(adiacenti5);
        
        ArrayList<Territorio> elencoT = new ArrayList<>();
        elencoT.add(t1);
        elencoT.add(t2);
        elencoT.add(t3);
        elencoT.add(t4);
        elencoT.add(t5);
        
        
        InterazioneUtente.interazionePrincipale(elencoT);
	}

}
