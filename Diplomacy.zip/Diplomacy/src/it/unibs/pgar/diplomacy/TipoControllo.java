package it.unibs.pgar.diplomacy;

public enum TipoControllo {
	CONTROLLATO,
	NEUTRO,
	VUOTO;
}
