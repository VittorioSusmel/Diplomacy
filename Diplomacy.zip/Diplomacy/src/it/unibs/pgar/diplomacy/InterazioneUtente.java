package it.unibs.pgar.diplomacy;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import it.unibs.fp.mylib.InputDati;

public class InterazioneUtente {
	private static final String TERRITORI_COSTIERI = "I territori costieri attualmente catturati sono:";
	private static final String TERRITORI_MARINI = "I territori marini attualmente catturati sono:";
	private static final String TERRITORI_CONTINENTALI = "I territori continentali catturati sono:";
	private static final String TERRITORI_CATTURATI = "TERRITORI CATTURATI";
	private static final String TERRITORI_ATTUALMENTE_OCCUPATI = "I territori attualmente occupati sono:";
	private static final String DOT = ".";
	private static final String NON_�_PI�_OCCUPATO = " non � pi� occupato.";
	private static final String AL_TERRITORIO = " al territorio ";
	private static final String SPOSTAMENTO_ARMATA = "Si � verificato uno spostamento di armata dal territorio ";
	private final static String AZIONE = "A";
	private final static String FLOTTA = "F";
	private final static String HOLD = "H";
	private final static String FINE_TURNO = "END";
	private final static String FINE_PARTITA = "EXIT";
	private final static String INTESTAZIONE_TURNO = "Per inserire un'azione digiti: A nomeTerritorioDiPartenza nomeTerritorioDiArrivo,"
			+ "sostituire F ad A nel caso si tratti di flotte.\n"
			+ "Per terminare il turno digiti END, per concludere la partita digiti EXIT.";
	
	
	/**
	 * Questo metodo si occupa della richiesta e raccolta di ordini inseriti dall'utente, questi, se validi,
	 * vengono elaborati attraverso la classe GestioneTurno.
	 * Il turno termina con la chiamata a GestioneTurno.completaTurno che elabora solo gli spostamenti effettivamente validi.
	 * 
	 * @param elencoTerritori: ArrayList<Territorio>
	 */
	public static void interazionePrincipale(ArrayList<Territorio> elencoTerritori) {
		
		//inizializzazione oggetti utili
		stampaTerritoriOccupati(elencoTerritori);
		stampaIntestazione();
		boolean prossimoOrdine = true;
		boolean prossimoTurno = true;
		boolean statoInput = true;
		ArrayList<String> elencoNomiZoneDiTerraECosta = new ArrayList<>();
		ArrayList<String> elencoNomiZoneDiTerraECostaCatturati = new ArrayList<>();
		ArrayList<String> elencoNomiZoneDiMareECosta = new ArrayList<>();
		ArrayList<String> elencoNomiZoneDiMareECostaCatturati = new ArrayList<>();
		ArrayList<Spostamento> elencoSpostamenti = new ArrayList<>();
		int stagione = 0;//valori pari per la primavera e valori dispari per l'autunno
		
		//l'occupazione si riferisce alla presenza di un'armata o di una flotta sul territorio
		//la cattura si riferisce al passaggio di un'armata o di una flotta sul territorio e alla conquista dello stesso
		//all'inizio di un'ipotetica partita 
		
		inizializzaElenchiTerritori(elencoTerritori, elencoNomiZoneDiTerraECosta, elencoNomiZoneDiTerraECostaCatturati, elencoNomiZoneDiMareECosta, elencoNomiZoneDiMareECostaCatturati);
		
		while(prossimoTurno) {
			elencoSpostamenti.clear();
		    while(prossimoOrdine) {
			
		    
	    	prossimoOrdine = true;
		    statoInput = true;
	    	Territorio t1 = new Territorio();
		    Territorio t2 = new Territorio();
		    
		//ipotizzando che i territori chiamati con i nomi inseriti siano gi� stati inizializzati
	    	String inputAzione = InputDati.leggiStringaNonVuota("");
	    	Scanner scanner = new Scanner(inputAzione);
	    	String azione = "";
	    	if(scanner.hasNext())
		    azione = scanner.next();
	    	if(scanner.hasNext())
	    	t1.setNome(scanner.next());
	    	if(scanner.hasNext())
	    	t2.setNome(scanner.next());
	    	scanner.close();  
		    
	    	switch(azione) {
	    	
	    	    case AZIONE:
	    	    	if(elencoNomiZoneDiTerraECosta.contains(t1.getNome()) || elencoNomiZoneDiTerraECosta.contains(t2.getNome()) || t2.getNome() == HOLD)
			        	statoInput = false;
			        	int n = elencoNomiZoneDiTerraECosta.indexOf(t1.getNome());
			        	t1 = (Territorio) elencoTerritori.get(n).clone();
			        	n = elencoNomiZoneDiTerraECosta.indexOf(t2.getNome());
			        	t2 = (Territorio) elencoTerritori.get(n).clone();
			        
			    
		    	    if(statoInput) {
			        GestioneTurno.valutaCondizioniArmata(t1, t2, elencoSpostamenti);
	                }
		    	    break;
	    	    	
	    	    case FLOTTA:
	    	    	
	    	    	if(elencoNomiZoneDiMareECosta.contains(t1.getNome()) || elencoNomiZoneDiMareECosta.contains(t2.getNome()) || t2.getNome() == HOLD) 
			        	statoInput = false;
	    	    	int m = elencoNomiZoneDiTerraECosta.indexOf(t1.getNome());
		        	t1 = (Territorio) elencoTerritori.get(m).clone();
		        	m = elencoNomiZoneDiTerraECosta.indexOf(t2.getNome());
		        	t2 = (Territorio) elencoTerritori.get(m).clone();
			        
			    
		    	    if(statoInput) {
			        GestioneTurno.valutaCondizioniFlotta(t1, t2, elencoSpostamenti);
	                }
		    	    break;
		    	    
	    	    case FINE_TURNO:
	    	    	prossimoOrdine = false;
	    	    	break;
	    	    	
	    	    case FINE_PARTITA:
	    	    	prossimoOrdine = false;
	    	    	prossimoTurno = false;
	    	    	break;
	    	    	
	    	    default:
	    	    	break;
	    	    
	    		
	    	}	 
    	    }
		    if(elencoSpostamenti.size() != 0)
		    	GestioneTurno.completaTurno(elencoSpostamenti);
		    stampaTerritoriOccupati(elencoTerritori);
		    if(stagione % 2 != 0)
		    	stampaTerritoriCatturati(elencoTerritori);
		    System.out.println();
		    System.out.println();
		    prossimoOrdine = true;
		    stagione++;
		}
		    
		    
	}
	
	/**
	 * Inizializza le arraylist contenenti i nomi dei territori e i nomi dei territori catturati
	 * 
	 * @param elencoTerritori: ArrayList<Territorio>
	 * @param elencoNomiZoneDiTerraECosta: ArrayList<String>
	 * @param elencoNomiZoneDiTerraECostaCatturati: ArrayList<String>
	 * @param elencoNomiZoneDiMareECosta: ArrayList<String>
	 * @param elencoNomiZoneDiMareECostaCatturati: ArrayList<String>
	 */
	private static void inizializzaElenchiTerritori(ArrayList<Territorio> elencoTerritori, ArrayList<String> elencoNomiZoneDiTerraECosta, ArrayList<String> elencoNomiZoneDiTerraECostaCatturati,ArrayList<String> elencoNomiZoneDiMareECosta, ArrayList<String> elencoNomiZoneDiMareECostaCatturati) {
		for (int i = 0; i < elencoTerritori.size(); i++) {
			if(elencoTerritori.get(i).getTipo() != Tipo.MARE)
		    	elencoNomiZoneDiTerraECosta.add(elencoTerritori.get(i).getNome());
			if(elencoTerritori.get(i).isOccupato())
		    	elencoNomiZoneDiTerraECostaCatturati.add(elencoTerritori.get(i).getNome());
	    	}
		
		for (int i = 0; i < elencoTerritori.size(); i++) {
			if(elencoTerritori.get(i).getTipo() != Tipo.TERRA)
	    	elencoNomiZoneDiMareECosta.add(elencoTerritori.get(i).getNome());
			if(elencoTerritori.get(i).isOccupato())
		    	elencoNomiZoneDiMareECostaCatturati.add(elencoTerritori.get(i).getNome());
    	}
	}
	
	/**
	 * Stampa uno spostamento dell'armata.
	 * 
	 * @param spostamento: Spostamento
	 */
	public static void stampaSpostamento(Spostamento spostamento) {
		System.out.println(SPOSTAMENTO_ARMATA + spostamento.getPartenza().getNome() + 
				AL_TERRITORIO + spostamento.getArrivo().getNome() + DOT);
		System.out.println(spostamento.getPartenza().getNome() + NON_�_PI�_OCCUPATO);
	}
	
	/**
	 * Stampa l'elenco dei territori attualmente occupati.
	 * Viene utilizzato sia all'inizio di un turno che alla fine
	 * 
	 * @param elencoTerritori: ArrayList<Territorio>
	 */
	private static void stampaTerritoriOccupati(ArrayList<Territorio> elencoTerritori) {
		System.out.println(TERRITORI_ATTUALMENTE_OCCUPATI);
		for (int i = 0; i < elencoTerritori.size(); i++) {
			if(elencoTerritori.get(i).isOccupato()) {
				System.out.println(elencoTerritori.get(i).getNome());
			}
		}
		System.out.println();
	}
	
	/**
	 * Stampa un'intestazione ad inizio turno per dare indicazioni riguardo l'input.
	 */
	private static void stampaIntestazione() {
		System.out.println(INTESTAZIONE_TURNO);
	}
	
	/**
	 * Stampa i territori catturati divisi per tipologia.
	 * 
	 * @param elencoTerritori: ArrayList<Territorio>
	 */
	private static void stampaTerritoriCatturati(ArrayList<Territorio> elencoTerritori) {
		System.out.println(TERRITORI_CATTURATI);
		System.out.println(TERRITORI_CONTINENTALI);
		for (int i = 0; i < elencoTerritori.size(); i++) {
			if(elencoTerritori.get(i).isCatturato() && elencoTerritori.get(i).getTipo() == Tipo.TERRA) {
				System.out.println(elencoTerritori.get(i).getNome());
			}
		}
		
		System.out.println();
		
		System.out.println(TERRITORI_MARINI);
		for (int i = 0; i < elencoTerritori.size(); i++) {
			if(elencoTerritori.get(i).isOccupato() && elencoTerritori.get(i).getTipo() == Tipo.MARE) {
				System.out.println(elencoTerritori.get(i).getNome());
			}
		}

		System.out.println();
		
		System.out.println(TERRITORI_COSTIERI);
		for (int i = 0; i < elencoTerritori.size(); i++) {
			if(elencoTerritori.get(i).isOccupato() && elencoTerritori.get(i).getTipo() == Tipo.COSTA) {
				System.out.println(elencoTerritori.get(i).getNome());
			}
		}
	}
	
}
			