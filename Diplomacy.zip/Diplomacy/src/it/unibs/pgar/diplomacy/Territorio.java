package it.unibs.pgar.diplomacy;

import java.util.ArrayList;

public class Territorio {
	private String nome;
	private Tipo tipo;
	private TipoControllo tipoControllo;
	private boolean centroNevralgico;
	private boolean occupato;
	private boolean catturato;
	private ArrayList<Territorio> territoriAdiacenti;
	private boolean modificatoInQuestoTurno;
	
	
	//COSTRUTTORI
	public Territorio() {
			super();
			this.nome = null;
			this.tipo = null;
			this.tipoControllo = null;
			this.centroNevralgico = false;
			this.territoriAdiacenti = null;
			this.modificatoInQuestoTurno = false;
			this.occupato = false;
			this.catturato = false;
	}

	public Territorio(String nome, Tipo tipo, TipoControllo tipoControllo, boolean centroNevralgico, ArrayList<Territorio> territoriAdiacenti, boolean situazioneIniziale, boolean catturato) {
		super();
		this.nome = nome;
		this.tipo = tipo;
		this.tipoControllo = tipoControllo;
		this.territoriAdiacenti = territoriAdiacenti;
		this.centroNevralgico = centroNevralgico;
		this.modificatoInQuestoTurno = false;
		this.occupato = situazioneIniziale;
		this.catturato = catturato;
	}
	
	public Territorio(String nome, Tipo tipo, TipoControllo tipoControllo, boolean centroNevralgico, boolean situazioneIniziale, boolean catturato) {
		super();
		this.nome = nome;
		this.tipo = tipo;
		this.tipoControllo = tipoControllo;
		this.territoriAdiacenti = null;
		this.centroNevralgico = centroNevralgico;
		this.modificatoInQuestoTurno = false;
		this.occupato = situazioneIniziale;
		this.catturato = catturato;
	}
	
	
    //GETTERS E SETTERS
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Tipo getTipo() {
		return tipo;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}

	public ArrayList<Territorio> getTerritoriAdiacenti() {
		return territoriAdiacenti;
	}

	public void setTerritoriAdiacenti(ArrayList<Territorio> territoriAdiacenti) {
		this.territoriAdiacenti = territoriAdiacenti;
	}

	public boolean isModificatoInQuestoTurno() {
		return modificatoInQuestoTurno;
	}

	public void setModificatoInQuestoTurno(boolean modificatoInQuestoTurno) {
		this.modificatoInQuestoTurno = modificatoInQuestoTurno;
	}
	
	public boolean isOccupato() {
		return occupato;
	}

	public void setOccupazione(boolean situazione) {
		this.occupato = situazione;
	}
		
	public TipoControllo getTipoControllo() {
		return tipoControllo;
	}

	public void setTipoControllo(TipoControllo tipoControllo) {
		this.tipoControllo = tipoControllo;
	}

	public boolean isCentroNevralgico() {
		return centroNevralgico;
	}

	public void setCentroNevralgico(boolean centroNevralgico) {
		this.centroNevralgico = centroNevralgico;
	}

	public boolean isCatturato() {
		return catturato;
	}

	public void setCatturato(boolean catturato) {
		this.catturato = catturato;
	}

	@Override
	public boolean equals(Object obj) {
		boolean equal = true;
		Territorio territorio = (Territorio) obj;
		if(!(this.nome).equals(territorio.getNome()))
			equal = false;
		if(!(this.tipo).equals(territorio.getTipo()))
			equal = false;
		
		return equal;
	}
	
	@Override
	public Object clone() {
		Territorio ter = new Territorio();
		ter.setNome(this.getNome());
		ter.setTipo(this.getTipo());
		ter.setTipoControllo(this.getTipoControllo());
		ter.setCatturato(this.isCatturato());
		ter.setCentroNevralgico(this.isCentroNevralgico());
		ter.setModificatoInQuestoTurno(this.isModificatoInQuestoTurno());
		ter.setOccupazione(this.isOccupato());
		ter.setTerritoriAdiacenti(this.getTerritoriAdiacenti());
		
		return ter;
	}
	
	

}
