package it.unibs.pgar.diplomacy;

public enum Tipo {
	TERRA,
	COSTA,
	MARE;
}
