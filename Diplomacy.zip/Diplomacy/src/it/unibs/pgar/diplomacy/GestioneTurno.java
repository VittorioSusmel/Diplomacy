package it.unibs.pgar.diplomacy;

import java.util.ArrayList;

public class GestioneTurno {
	
	/**
	 * Valuta che l'armata non si stia spostando tra due zone di mare oppure territori non adiacenti.
	 * 
	 * @param territorioPartenza: Territorio
	 * @param territorioArrivo: Territorio
	 * @param elencoSpostamenti: ArrayList<Spostamento>
	 */
	public static void valutaCondizioniArmata(Territorio territorioPartenza, Territorio territorioArrivo, ArrayList<Spostamento> elencoSpostamenti) {
		if(territorioPartenza.getTipo() != Tipo.MARE && territorioArrivo.getTipo() != Tipo.MARE && 
				   territorioPartenza.getTerritoriAdiacenti().contains(territorioArrivo)) {
					Spostamento spostamento = new Spostamento(territorioPartenza, territorioArrivo);
					elencoSpostamenti.add(spostamento);
				}
	}
	
	/**
	 * Valuta che la flotta non si stia spostando tra due zone di terra oppure territori non adiacenti.
	 * 
	 * @param territorioPartenza: Territorio
	 * @param territorioArrivo: Territorio
	 * @param elencoSpostamenti: ArrayList<Spostamento>
	 */
	public static void valutaCondizioniFlotta(Territorio territorioPartenza, Territorio territorioArrivo, ArrayList<Spostamento> elencoSpostamenti) {
		if(territorioPartenza.getTipo() != Tipo.TERRA && territorioArrivo.getTipo() != Tipo.TERRA && 
				   territorioPartenza.getTerritoriAdiacenti().contains(territorioArrivo)) {
					Spostamento spostamento = new Spostamento(territorioPartenza, territorioArrivo);
					elencoSpostamenti.add(spostamento);
				}
	}
	
	/**
	 * Cambia lo stato di occupazione del territorio di partenza e di quello di arrivo
	 * dopo che sono stati eseguiti i controlli riguardo la validit� dello spostamento.
	 * 
	 * @param spostamento: Spostamento
	 */
	private static void eseguiSpostamento(Spostamento spostamento) {
		spostamento.getPartenza().setOccupazione(false);
		spostamento.getPartenza().setCatturato(true);
		spostamento.getArrivo().setOccupazione(true);
		spostamento.getArrivo().setCatturato(true);
		InterazioneUtente.stampaSpostamento(spostamento);
	}
	
	/**
	 * Elimina dall'elenco gli spostamenti ancora non validi, 
	 * ovvero quelli in cui si verifica un "conflitto" tra due spostamenti.
	 * 
	 * @param elencoSpostamenti: ArrayList<Spostamento>
	 */
	public static void completaTurno(ArrayList<Spostamento> elencoSpostamenti) {
		
		for(int i = 0; i < elencoSpostamenti.size(); i++) {
			if(elencoSpostamenti.get(i).getPartenza().isOccupato() == false) {
				elencoSpostamenti.remove(i);
			}
		}
		
		for(int i = 0; i < elencoSpostamenti.size(); i++) {
			if(elencoSpostamenti.get(i).getArrivo().isOccupato() == true) {
				elencoSpostamenti.remove(i);
			}
		}
		
		for(int i = 0; i < elencoSpostamenti.size(); i++) {
			for(int j = i + 1; j < elencoSpostamenti.size(); j++) {
				if(elencoSpostamenti.get(i).getArrivo() == elencoSpostamenti.get(j).getArrivo()) {
					elencoSpostamenti.remove(i);
					elencoSpostamenti.remove(j);
				}
			}
		}
		
		for(int i = 0; i < elencoSpostamenti.size(); i++) {
			for(int j = i + 1; j < elencoSpostamenti.size(); j++) {
				if(elencoSpostamenti.get(i).getPartenza() == elencoSpostamenti.get(j).getPartenza()) {
					elencoSpostamenti.remove(i);
					elencoSpostamenti.remove(j);
				}
			}
		}
		
		for(int i = 0; i < elencoSpostamenti.size(); i++) {
			eseguiSpostamento(elencoSpostamenti.get(i));
		}
		
	}

}
