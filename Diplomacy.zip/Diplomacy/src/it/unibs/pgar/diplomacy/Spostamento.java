package it.unibs.pgar.diplomacy;

public class Spostamento {
	private Territorio partenza;
	private Territorio arrivo;
	
	public Spostamento(Territorio partenza, Territorio arrivo) {
		super();
		this.partenza = partenza;
		this.arrivo = arrivo;
	}

	public Territorio getPartenza() {
		return partenza;
	}

	public void setPartenza(Territorio partenza) {
		this.partenza = partenza;
	}

	public Territorio getArrivo() {
		return arrivo;
	}

	public void setArrivo(Territorio arrivo) {
		this.arrivo = arrivo;
	}
	
	

}
